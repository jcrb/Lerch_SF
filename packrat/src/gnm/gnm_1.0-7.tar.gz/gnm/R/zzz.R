.onUnload <- function(libpath) {
    library.dynam.unload("gnm", libpath)
}
