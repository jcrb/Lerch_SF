prattle <- function(...) {
   cat(...)
   flush.console()
}
