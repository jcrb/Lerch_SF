ofInterest <- function(object) {
    object$ofInterest
}
