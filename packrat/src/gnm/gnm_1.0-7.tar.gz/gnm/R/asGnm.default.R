asGnm.default <- function (object, ...) {
    stop("\nCannot coerce objects of class \"", class(object),
         "\" to class \"gnm\".")
}
