termPredictors <- function(object, ...) {
    UseMethod("termPredictors")
}
